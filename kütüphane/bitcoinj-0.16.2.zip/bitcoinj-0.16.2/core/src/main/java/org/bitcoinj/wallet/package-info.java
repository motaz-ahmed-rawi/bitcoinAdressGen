/*
 * Copyright by the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Classes that support the {@link org.bitcoinj.wallet.Wallet}, which knows how to find and save transactions relevant to
 * a set of keys or scripts, calculate balances, and spend money: the wallet has many features and can be extended
 * in various ways, please refer to the website for documentation on how to use it.
 */
package org.bitcoinj.wallet;